# Lab 7 - Shopping Cart Fuzz Testing

Shesanth | PES1UG24AM261

The original shopping cart program crashes for invalid cart entries, promo codes and pincodes. I added input validation and used pytest and Hypothesis to test the three functions.

## Files

- `shopping_cart.py` - corrected application
- `test_shopping_cart.py` - Hypothesis fuzz tests
- `test_validation.py` - extra regression tests for edge cases
- `requirements.txt` - testing dependencies

## Run

```bash
python -m pip install -r requirements.txt
python shopping_cart.py
python -m pytest test_shopping_cart.py -v
python -m pytest test_validation.py -v
```

Input rules used for the fix: malformed carts and promo codes return `0`; invalid pincodes return `Invalid Pincode`. Cart entries use `name:pricexquantity`, promo codes use `OFF` followed by 0-100, and pincodes need six digits starting from 1 to 8.
