"""Executable deterministic validation when Hypothesis is unavailable."""
import pytest
from shopping_cart import cart_total, promo_percent, delivery_zone

@pytest.mark.parametrize('input_value,expected', [
    ('pen:10x2,book:250x1',270), ('pen:0x5',0), ('',0), (None,0),
    ('pen:-10x2',0), ('pen:10x-2',0), ('pen:10x2,',0), ('pen:abcx1',0),
    (',',0), ('  pen:2x4  ',8), (42,0)
])
def test_cart(input_value, expected):
    assert cart_total(input_value) == expected

@pytest.mark.parametrize('input_value,expected', [
    ('OFF20',20), ('off20',20), ('OFF0',0), ('OFF100',100),
    ('OFF101',0), ('OFF999',0), ('BAD',0), (None,0), ('',0),
    (' OFF50 ',50), (42,0)
])
def test_promo(input_value, expected):
    assert promo_percent(input_value) == expected

@pytest.mark.parametrize('input_value,expected', [
    ('560085','South'), ('100000','North'), ('300000','West'),
    ('800000','East'), ('900000','Invalid Pincode'), ('','Invalid Pincode'),
    (None,'Invalid Pincode'), ('56008','Invalid Pincode'),
    ('5600850','Invalid Pincode'), ('A60085','Invalid Pincode'),
    (123456,'Invalid Pincode')
])
def test_zone(input_value, expected):
    assert delivery_zone(input_value) == expected
