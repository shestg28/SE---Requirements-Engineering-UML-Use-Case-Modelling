"""Lab 7 Hypothesis fuzz tests for all three shopping-cart functions."""
from hypothesis import given, settings, strategies as st
from shopping_cart import cart_total, promo_percent, delivery_zone


@settings(max_examples=200, deadline=None)
@given(st.text() | st.none())
def test_cart_total_no_crash(s):
    result = cart_total(s)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=200, deadline=None)
@given(st.text() | st.none())
def test_promo_percent_no_crash(s):
    result = promo_percent(s)
    assert isinstance(result, int)
    assert 0 <= result <= 100


@settings(max_examples=200, deadline=None)
@given(st.text() | st.none())
def test_delivery_zone_no_crash(s):
    result = delivery_zone(s)
    assert isinstance(result, str)
    assert result in {'North', 'West', 'South', 'East', 'Invalid Pincode'}


@given(st.lists(st.tuples(st.text(alphabet='abcdefghijklmnopqrstuvwxyz', min_size=1, max_size=12),
                           st.integers(min_value=0, max_value=100000),
                           st.integers(min_value=0, max_value=1000)),
                min_size=1, max_size=12))
def test_cart_total_correct_for_valid_carts(items):
    cart = ','.join(f'{name}:{price}x{qty}' for name, price, qty in items)
    assert cart_total(cart) == sum(price * qty for _, price, qty in items)


@given(st.integers(min_value=0, max_value=100))
def test_promo_percent_correct_for_valid_codes(value):
    assert promo_percent(f'OFF{value}') == value
    assert promo_percent(f'off{value}') == value


@given(st.sampled_from(list('12345678')), st.text(alphabet='0123456789', min_size=5, max_size=5))
def test_delivery_zone_correct_for_valid_pincodes(first, rest):
    expected = {'1': 'North', '2': 'North', '3': 'West', '4': 'West',
                '5': 'South', '6': 'South', '7': 'East', '8': 'East'}[first]
    assert delivery_zone(first + rest) == expected


def test_explicit_invalid_inputs():
    assert cart_total('1,,3') == 0
    assert cart_total(None) == 0
    assert cart_total('pen:-10x2') == 0
    assert cart_total('pen:10x-2') == 0
    assert promo_percent(None) == 0
    assert promo_percent('OFF999') == 0
    assert promo_percent('hello') == 0
    assert delivery_zone(None) == 'Invalid Pincode'
    assert delivery_zone('') == 'Invalid Pincode'
    assert delivery_zone('960085') == 'Invalid Pincode'
    assert delivery_zone('56008') == 'Invalid Pincode'
