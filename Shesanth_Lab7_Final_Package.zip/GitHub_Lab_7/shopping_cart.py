"""Robust shopping-cart input processing for Lab 7 fuzz testing.

Invalid input is handled safely without exceptions:
- cart_total -> 0
- promo_percent -> 0
- delivery_zone -> 'Invalid Pincode'
"""
import re

ZONES = {"1": "North", "2": "North", "3": "West", "4": "West",
         "5": "South", "6": "South", "7": "East", "8": "East"}

_ITEM = re.compile(r"([^,:]+):([0-9]+)x([0-9]+)\Z")
_PROMO = re.compile(r"OFF([0-9]{1,3})\Z", re.IGNORECASE)
_PIN = re.compile(r"[0-9]{6}\Z")


def cart_total(cart):
    """Sum a CSV of name:pricexqty items; return 0 for malformed input."""
    if not isinstance(cart, str) or not cart.strip():
        return 0
    total = 0
    for raw_item in cart.split(','):
        match = _ITEM.fullmatch(raw_item.strip())
        if match is None or not match.group(1).strip():
            return 0
        price, quantity = int(match.group(2)), int(match.group(3))
        total += price * quantity
    return total


def promo_percent(code):
    """Extract OFF0..OFF100 case-insensitively; invalid codes give 0."""
    if not isinstance(code, str):
        return 0
    match = _PROMO.fullmatch(code.strip())
    if match is None:
        return 0
    percent = int(match.group(1))
    return percent if 0 <= percent <= 100 else 0


def delivery_zone(pincode):
    """Return zone for a valid six-digit Indian-style code starting 1..8."""
    if not isinstance(pincode, str):
        return 'Invalid Pincode'
    pincode = pincode.strip()
    if not _PIN.fullmatch(pincode):
        return 'Invalid Pincode'
    return ZONES.get(pincode[0], 'Invalid Pincode')


def main():
    print('==== Running cart_total ====')
    user_input = input('Enter cart as name:pricexqty CSV (e.g. pen:10x2,book:250x1): ')
    print('Cart Total:', cart_total(user_input))

    print('\n==== Running promo_percent ====')
    user_input = input('Enter a promo code (e.g. OFF20): ')
    print('Discount Percent:', promo_percent(user_input))

    print('\n==== Running delivery_zone ====')
    user_input = input('Enter a 6 digit pincode (e.g. 560085): ')
    print('Delivery Zone:', delivery_zone(user_input))


if __name__ == '__main__':
    main()
